﻿namespace EstadisticaCampeonato
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtNombreEquipo = new System.Windows.Forms.TextBox();
            this.txtPaisEquipo = new System.Windows.Forms.TextBox();
            this.btnAgregarEquipo = new System.Windows.Forms.Button();
            this.dtpFechaPartido = new System.Windows.Forms.DateTimePicker();
            this.txtEstadio = new System.Windows.Forms.TextBox();
            this.txtEquipoLocal = new System.Windows.Forms.TextBox();
            this.txtEquipoVisitante = new System.Windows.Forms.TextBox();
            this.txtGolesLocal = new System.Windows.Forms.TextBox();
            this.txtGolesVisitante = new System.Windows.Forms.TextBox();
            this.btnAgregarPartido = new System.Windows.Forms.Button();
            this.txtNombreJugador = new System.Windows.Forms.TextBox();
            this.txtEdadJugador = new System.Windows.Forms.TextBox();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.txtLigaJugador = new System.Windows.Forms.TextBox();
            this.txtEquipoJugador = new System.Windows.Forms.TextBox();
            this.btnAgregarJugador = new System.Windows.Forms.Button();
            this.btnVerEquipos = new System.Windows.Forms.Button();
            this.btnVerPartidos = new System.Windows.Forms.Button();
            this.btnVerJugadores = new System.Windows.Forms.Button();
            this.lstEquipos = new System.Windows.Forms.ListBox();
            this.lstPartidos = new System.Windows.Forms.ListBox();
            this.lstJugadores = new System.Windows.Forms.ListBox();
            this.txtEquipoVerJugadores = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtNombreEquipo
            // 
            this.txtNombreEquipo.Location = new System.Drawing.Point(13, 13);
            this.txtNombreEquipo.Name = "txtNombreEquipo";
            this.txtNombreEquipo.Size = new System.Drawing.Size(100, 20);
            this.txtNombreEquipo.TabIndex = 0;
            // 
            // txtPaisEquipo
            // 
            this.txtPaisEquipo.Location = new System.Drawing.Point(13, 40);
            this.txtPaisEquipo.Name = "txtPaisEquipo";
            this.txtPaisEquipo.Size = new System.Drawing.Size(100, 20);
            this.txtPaisEquipo.TabIndex = 1;
            // 
            // btnAgregarEquipo
            // 
            this.btnAgregarEquipo.Location = new System.Drawing.Point(13, 67);
            this.btnAgregarEquipo.Name = "btnAgregarEquipo";
            this.btnAgregarEquipo.Size = new System.Drawing.Size(100, 23);
            this.btnAgregarEquipo.TabIndex = 2;
            this.btnAgregarEquipo.Text = "Agregar Equipo";
            this.btnAgregarEquipo.UseVisualStyleBackColor = true;
            this.btnAgregarEquipo.Click += new System.EventHandler(this.btnAgregarEquipo_Click);
            // 
            // dtpFechaPartido
            // 
            this.dtpFechaPartido.Location = new System.Drawing.Point(13, 97);
            this.dtpFechaPartido.Name = "dtpFechaPartido";
            this.dtpFechaPartido.Size = new System.Drawing.Size(200, 20);
            this.dtpFechaPartido.TabIndex = 3;
            // 
            // txtEstadio
            // 
            this.txtEstadio.Location = new System.Drawing.Point(13, 124);
            this.txtEstadio.Name = "txtEstadio";
            this.txtEstadio.Size = new System.Drawing.Size(100, 20);
            this.txtEstadio.TabIndex = 4;
            // 
            // txtEquipoLocal
            // 
            this.txtEquipoLocal.Location = new System.Drawing.Point(13, 151);
            this.txtEquipoLocal.Name = "txtEquipoLocal";
            this.txtEquipoLocal.Size = new System.Drawing.Size(100, 20);
            this.txtEquipoLocal.TabIndex = 5;
            // 
            // txtEquipoVisitante
            // 
            this.txtEquipoVisitante.Location = new System.Drawing.Point(13, 178);
            this.txtEquipoVisitante.Name = "txtEquipoVisitante";
            this.txtEquipoVisitante.Size = new System.Drawing.Size(100, 20);
            this.txtEquipoVisitante.TabIndex = 6;
            // 
            // txtGolesLocal
            // 
            this.txtGolesLocal.Location = new System.Drawing.Point(13, 205);
            this.txtGolesLocal.Name = "txtGolesLocal";
            this.txtGolesLocal.Size = new System.Drawing.Size(100, 20);
            this.txtGolesLocal.TabIndex = 7;
            // 
            // txtGolesVisitante
            // 
            this.txtGolesVisitante.Location = new System.Drawing.Point(13, 232);
            this.txtGolesVisitante.Name = "txtGolesVisitante";
            this.txtGolesVisitante.Size = new System.Drawing.Size(100, 20);
            this.txtGolesVisitante.TabIndex = 8;
            // 
            // btnAgregarPartido
            // 
            this.btnAgregarPartido.Location = new System.Drawing.Point(13, 259);
            this.btnAgregarPartido.Name = "btnAgregarPartido";
            this.btnAgregarPartido.Size = new System.Drawing.Size(100, 23);
            this.btnAgregarPartido.TabIndex = 9;
            this.btnAgregarPartido.Text = "Agregar Partido";
            this.btnAgregarPartido.UseVisualStyleBackColor = true;
            this.btnAgregarPartido.Click += new System.EventHandler(this.btnAgregarPartido_Click);
            // 
            // txtNombreJugador
            // 
            this.txtNombreJugador.Location = new System.Drawing.Point(13, 289);
            this.txtNombreJugador.Name = "txtNombreJugador";
            this.txtNombreJugador.Size = new System.Drawing.Size(100, 20);
            this.txtNombreJugador.TabIndex = 10;
            // 
            // txtEdadJugador
            // 
            this.txtEdadJugador.Location = new System.Drawing.Point(13, 316);
            this.txtEdadJugador.Name = "txtEdadJugador";
            this.txtEdadJugador.Size = new System.Drawing.Size(100, 20);
            this.txtEdadJugador.TabIndex = 11;
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(13, 343);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(200, 20);
            this.dtpFechaNacimiento.TabIndex = 12;
            // 
            // txtLigaJugador
            // 
            this.txtLigaJugador.Location = new System.Drawing.Point(13, 370);
            this.txtLigaJugador.Name = "txtLigaJugador";
            this.txtLigaJugador.Size = new System.Drawing.Size(100, 20);
            this.txtLigaJugador.TabIndex = 13;
            // 
            // txtEquipoJugador
            // 
            this.txtEquipoJugador.Location = new System.Drawing.Point(13, 397);
            this.txtEquipoJugador.Name = "txtEquipoJugador";
            this.txtEquipoJugador.Size = new System.Drawing.Size(100, 20);
            this.txtEquipoJugador.TabIndex = 14;
            // 
            // btnAgregarJugador
            // 
            this.btnAgregarJugador.Location = new System.Drawing.Point(13, 424);
            this.btnAgregarJugador.Name = "btnAgregarJugador";
            this.btnAgregarJugador.Size = new System.Drawing.Size(100, 23);
            this.btnAgregarJugador.TabIndex = 15;
            this.btnAgregarJugador.Text = "Agregar Jugador";
            this.btnAgregarJugador.UseVisualStyleBackColor = true;
            this.btnAgregarJugador.Click += new System.EventHandler(this.btnAgregarJugador_Click);
            // 
            // btnVerEquipos
            // 
            this.btnVerEquipos.Location = new System.Drawing.Point(13, 454);
            this.btnVerEquipos.Name = "btnVerEquipos";
            this.btnVerEquipos.Size = new System.Drawing.Size(100, 23);
            this.btnVerEquipos.TabIndex = 16;
            this.btnVerEquipos.Text = "Ver Equipos";
            this.btnVerEquipos.UseVisualStyleBackColor = true;
            this.btnVerEquipos.Click += new System.EventHandler(this.btnVerEquipos_Click);
            // 
            // btnVerPartidos
            // 
            this.btnVerPartidos.Location = new System.Drawing.Point(13, 484);
            this.btnVerPartidos.Name = "btnVerPartidos";
            this.btnVerPartidos.Size = new System.Drawing.Size(100, 23);
            this.btnVerPartidos.TabIndex = 17;
            this.btnVerPartidos.Text = "Ver Partidos";
            this.btnVerPartidos.UseVisualStyleBackColor = true;
            this.btnVerPartidos.Click += new System.EventHandler(this.btnVerPartidos_Click);
            // 
            // btnVerJugadores
            // 
            this.btnVerJugadores.Location = new System.Drawing.Point(13, 514);
            this.btnVerJugadores.Name = "btnVerJugadores";
            this.btnVerJugadores.Size = new System.Drawing.Size(100, 23);
            this.btnVerJugadores.TabIndex = 18;
            this.btnVerJugadores.Text = "Ver Jugadores";
            this.btnVerJugadores.UseVisualStyleBackColor = true;
            this.btnVerJugadores.Click += new System.EventHandler(this.btnVerJugadores_Click);
            // 
            // lstEquipos
            // 
            this.lstEquipos.FormattingEnabled = true;
            this.lstEquipos.Location = new System.Drawing.Point(220, 13);
            this.lstEquipos.Name = "lstEquipos";
            this.lstEquipos.Size = new System.Drawing.Size(200, 95);
            this.lstEquipos.TabIndex = 19;
            // 
            // lstPartidos
            // 
            this.lstPartidos.FormattingEnabled = true;
            this.lstPartidos.Location = new System.Drawing.Point(220, 124);
            this.lstPartidos.Name = "lstPartidos";
            this.lstPartidos.Size = new System.Drawing.Size(200, 95);
            this.lstPartidos.TabIndex = 20;
            // 
            // lstJugadores
            // 
            this.lstJugadores.FormattingEnabled = true;
            this.lstJugadores.Location = new System.Drawing.Point(220, 235);
            this.lstJugadores.Name = "lstJugadores";
            this.lstJugadores.Size = new System.Drawing.Size(200, 95);
            this.lstJugadores.TabIndex = 21;
            // 
            // txtEquipoVerJugadores
            // 
            this.txtEquipoVerJugadores.Location = new System.Drawing.Point(220, 343);
            this.txtEquipoVerJugadores.Name = "txtEquipoVerJugadores";
            this.txtEquipoVerJugadores.Size = new System.Drawing.Size(100, 20);
            this.txtEquipoVerJugadores.TabIndex = 22;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtEquipoVerJugadores);
            this.Controls.Add(this.lstJugadores);
            this.Controls.Add(this.lstPartidos);
            this.Controls.Add(this.lstEquipos);
            this.Controls.Add(this.btnVerJugadores);
            this.Controls.Add(this.btnVerPartidos);
            this.Controls.Add(this.btnVerEquipos);
            this.Controls.Add(this.btnAgregarJugador);
            this.Controls.Add(this.txtEquipoJugador);
            this.Controls.Add(this.txtLigaJugador);
            this.Controls.Add(this.dtpFechaNacimiento);
            this.Controls.Add(this.txtEdadJugador);
            this.Controls.Add(this.txtNombreJugador);
            this.Controls.Add(this.btnAgregarPartido);
            this.Controls.Add(this.txtGolesVisitante);
            this.Controls.Add(this.txtGolesLocal);
            this.Controls.Add(this.txtEquipoVisitante);
            this.Controls.Add(this.txtEquipoLocal);
            this.Controls.Add(this.txtEstadio);
            this.Controls.Add(this.dtpFechaPartido);
            this.Controls.Add(this.btnAgregarEquipo);
            this.Controls.Add(this.txtPaisEquipo);
            this.Controls.Add(this.txtNombreEquipo);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtNombreEquipo;
        private System.Windows.Forms.TextBox txtPaisEquipo;
        private System.Windows.Forms.Button btnAgregarEquipo;
        private System.Windows.Forms.DateTimePicker dtpFechaPartido;
        private System.Windows.Forms.TextBox txtEstadio;
        private System.Windows.Forms.TextBox txtEquipoLocal;
        private System.Windows.Forms.TextBox txtEquipoVisitante;
        private System.Windows.Forms.TextBox txtGolesLocal;
        private System.Windows.Forms.TextBox txtGolesVisitante;
        private System.Windows.Forms.Button btnAgregarPartido;
        private System.Windows.Forms.TextBox txtNombreJugador;
        private System.Windows.Forms.TextBox txtEdadJugador;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
        private System.Windows.Forms.TextBox txtLigaJugador;
        private System.Windows.Forms.TextBox txtEquipoJugador;
        private System.Windows.Forms.Button btnAgregarJugador;
        private System.Windows.Forms.Button btnVerEquipos;
        private System.Windows.Forms.Button btnVerPartidos;
        private System.Windows.Forms.Button btnVerJugadores;
        private System.Windows.Forms.ListBox lstEquipos;
        private System.Windows.Forms.ListBox lstPartidos;
        private System.Windows.Forms.ListBox lstJugadores;
        private System.Windows.Forms.TextBox txtEquipoVerJugadores;
    }
}


