﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace EstadisticaCampeonato
{
    public partial class Form1 : Form
    {
        private List<Equipo> equipos = new List<Equipo>();
        private List<Partido> partidos = new List<Partido>();
        private List<Jugador> jugadores = new List<Jugador>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Inicializar datos si es necesario
        }

        private void btnAgregarEquipo_Click(object sender, EventArgs e)
        {
            string nombre = txtNombreEquipo.Text;
            string pais = txtPaisEquipo.Text;
            equipos.Add(new Equipo(nombre, pais));
            MessageBox.Show("Equipo agregado correctamente");
            txtNombreEquipo.Clear();
            txtPaisEquipo.Clear();
        }

        private void btnAgregarPartido_Click(object sender, EventArgs e)
        {
            DateTime fecha = dtpFechaPartido.Value;
            string estadio = txtEstadio.Text;
            string equipoLocal = txtEquipoLocal.Text;
            string equipoVisitante = txtEquipoVisitante.Text;
            int golesLocal = int.Parse(txtGolesLocal.Text);
            int golesVisitante = int.Parse(txtGolesVisitante.Text);

            partidos.Add(new Partido(fecha, estadio, equipoLocal, equipoVisitante, golesLocal, golesVisitante));
            MessageBox.Show("Partido agregado correctamente");
            txtEstadio.Clear();
            txtEquipoLocal.Clear();
            txtEquipoVisitante.Clear();
            txtGolesLocal.Clear();
            txtGolesVisitante.Clear();
        }

        private void btnAgregarJugador_Click(object sender, EventArgs e)
        {
            string nombre = txtNombreJugador.Text;
            int edad = int.Parse(txtEdadJugador.Text);
            DateTime fechaNacimiento = dtpFechaNacimiento.Value;
            string liga = txtLigaJugador.Text;
            string equipo = txtEquipoJugador.Text;

            jugadores.Add(new Jugador(nombre, edad, fechaNacimiento, liga));
            MessageBox.Show("Jugador agregado correctamente");
            txtNombreJugador.Clear();
            txtEdadJugador.Clear();
            txtLigaJugador.Clear();
            txtEquipoJugador.Clear();
        }

        private void btnVerEquipos_Click(object sender, EventArgs e)
        {
            lstEquipos.Items.Clear();
            foreach (var equipo in equipos)
            {
                lstEquipos.Items.Add($"{equipo.Nombre} - {equipo.PaisOrigen}");
            }
        }

        private void btnVerPartidos_Click(object sender, EventArgs e)
        {
            lstPartidos.Items.Clear();
            foreach (var partido in partidos)
            {
                lstPartidos.Items.Add($"{partido.Fecha.ToShortDateString()} - {partido.EquipoLocal} vs {partido.EquipoVisitante} - {partido.GolesEquipoLocal}:{partido.GolesEquipoVisitante}");
            }
        }

        private void btnVerJugadores_Click(object sender, EventArgs e)
        {
            string equipoFiltrar = txtEquipoVerJugadores.Text;
            lstJugadores.Items.Clear();
            foreach (var jugador in jugadores)
            {
                if (jugador.Liga == equipoFiltrar)
                {
                    lstJugadores.Items.Add($"{jugador.Nombre} - {jugador.Edad} años - {jugador.Liga}");
                }
            }
        }
    }

    public class Equipo
    {
        public string Nombre { get; set; }
        public string PaisOrigen { get; set; }

        public Equipo(string nombre, string paisOrigen)
        {
            Nombre = nombre;
            PaisOrigen = paisOrigen;
        }
    }

    public class Partido
    {
        public DateTime Fecha { get; set; }
        public string Estadio { get; set; }
        public string EquipoLocal { get; set; }
        public string EquipoVisitante { get; set; }
        public int GolesEquipoLocal { get; set; }
        public int GolesEquipoVisitante { get; set; }

        public Partido(DateTime fecha, string estadio, string equipoLocal, string equipoVisitante, int golesEquipoLocal, int golesEquipoVisitante)
        {
            Fecha = fecha;
            Estadio = estadio;
            EquipoLocal = equipoLocal;
            EquipoVisitante = equipoVisitante;
            GolesEquipoLocal = golesEquipoLocal;
            GolesEquipoVisitante = golesEquipoVisitante;
        }
    }

    public class Jugador
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Liga { get; set; }

        public Jugador(string nombre, int edad, DateTime fechaNacimiento, string liga)
        {
            Nombre = nombre;
            Edad = edad;
            FechaNacimiento = fechaNacimiento;
            Liga = liga;
        }
    }
}


